mobile-disk-sdk-android
=======================

SDK for Disk on Android

https://github.com/yandex-disk/yandex-disk-sdk-java
use master branch for Android version
use j2se branch for J2SE version


