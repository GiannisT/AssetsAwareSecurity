package com.yandex.disk.client.exceptions;

public class WebdavSharingForbiddenException extends WebdavException{

    public WebdavSharingForbiddenException(String detailMessage) {
        super(detailMessage);
    }
}
